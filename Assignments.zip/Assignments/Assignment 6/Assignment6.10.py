lt = []
for i in range(100,501):
    if i%2==0:
        lt.append(i)
print(sum(lt))