import time
t = time.strftime("%H:%M:%S")
print('Current time is ', t)