import random

s = int(input("Enter starting range : "))
e = int(input("Enter ending range : "))
random_integer = random.randint(s, e)
print(random_integer)
