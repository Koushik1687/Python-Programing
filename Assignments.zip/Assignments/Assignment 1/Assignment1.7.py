celcius = int(input("Celcius :"))
fernhite = celcius *(9/5)+32
print("Fernhite : {:.2f}".format(fernhite))