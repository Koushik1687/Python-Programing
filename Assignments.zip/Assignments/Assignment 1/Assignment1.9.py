cm=float(input("Enter the height in centimeters:"))
feet=0.0328*cm
print("The length in feet and inch",round(feet,2))