name = input("Please Enter Your Name :")
print("Welcome",name)