second = 365*24*60*60
print(second)