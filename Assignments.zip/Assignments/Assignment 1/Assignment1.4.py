ch = input("Please Enter Charater :")
print("The ASCII value of "+ ch +" is:", ord(ch))