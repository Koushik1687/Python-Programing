Base = float(input("Please enter the base : "))
Height = float(input("Please enter the height : "))
Area = 0.5*Base*Height
print("The area of triangle is : {:.2f}".format(Area))