radius = float(input("Please enter the radius :"))
area = 3.14159 *(radius*radius)
print("The area of the :{:.5f}".format(area))