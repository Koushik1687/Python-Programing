n = int(input("Please enter a number : "))
print(n, "^2 = ", pow(n, 2), sep="")
print(n, "^3 = ", pow(n, 3), sep="")
print(n, "^4 = ", pow(n, 4), sep="")
