num = int(input("Please enter a number : "))
print(num, num+1, num+2)
# for i in range(1, 3):
#     print(num)
#     print(num+i)
