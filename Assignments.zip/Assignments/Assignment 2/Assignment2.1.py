s=input("Good Morning !!")
print("How are you ?")