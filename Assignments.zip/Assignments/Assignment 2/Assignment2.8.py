num1 = int(input("Please enter num1 : "))
num2 = int(input("Please enter num2 : "))
num3 = int(input("Please enter num3  : "))
if num1 == num2 == num3:
    print("All the elements are same !!")
else : 
    print("Elements are not same ")