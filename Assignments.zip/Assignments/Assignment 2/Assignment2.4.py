weight = int(input("Please enter the Weight : "))
height = float(input("Please enter the height in Meters : "))
BMI = (weight)/pow(height, 2)
print("The BMI is : {:.2f}".format(BMI))
