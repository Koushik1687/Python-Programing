rupee = float(input("Please enter rupee you want to convert : "))
dollar = rupee/86.52
print("Dollar $ : {:.2f}".format(dollar))
