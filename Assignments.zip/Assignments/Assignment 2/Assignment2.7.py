string = input("Please enter 3 numbers :")
print(string[::-1])