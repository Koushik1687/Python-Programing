l1 = input("Please enter a list : ").split()
l2 = input("Please enter a list : ").split()
l3 = l1 + l2
print(type(l3),l3)