count = []
for i in range(0,49):
    count.append(i)  
print(count)
