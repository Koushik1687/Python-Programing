m_d={
    "January": 31,
    "February": 28,
    "March": 31,
    "Apri": 30,
    "May": 31,
    "June": 30,
    "July": 31,
    "August": 31,
    "September": 30,
    "October": 31,
    "November": 30,
    "Decmember": 31
}
for months, dates in m_d.items():
    print(f"{months}:{dates}")