lst = []
for i in range(1,50):
    lst.append(pow(i,2))    
print(lst)
