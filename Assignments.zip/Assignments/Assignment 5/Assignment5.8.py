L = [1, 2, 3, 4, 5]
M = [6, 7, 8, 9, 10]

N = [L[i] + M[i] for i in range(len(L))]

print("New list N:", N)
