from num2words import num2words
n = int(input("Enter a number : "))
word = num2words(n)
print(word)

