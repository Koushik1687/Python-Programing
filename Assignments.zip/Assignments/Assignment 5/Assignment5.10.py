lt=[]
for i in range (97,123):
    lt.append(chr(i) * (i - 96))
print(lt)