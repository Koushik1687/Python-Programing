file=open("D:\\Coding\\Python\\Python-Programing\\Assignments\\Assignment 8\\Assignment8.5.txt",'r')
data=file.readlines()
print("Last Line : ",data[-1])
file.close()