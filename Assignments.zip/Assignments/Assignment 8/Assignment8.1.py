with open("D:\\Coding\\Python\\Python-Programing\\Assignments\\Assignment 8\\Assignment8.1.txt", 'r')as demo:
    print(demo.read())