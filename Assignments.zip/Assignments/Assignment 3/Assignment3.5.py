s = input("Please enter something : ")
print(s[::-1])