i=input("Enter a word : ")
for k in range(0,len(i),2):
    print(i[k:k+2])