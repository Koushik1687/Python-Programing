sen = input("Please Enter Something : ").split()

print("The longest word:",max(sen,key=len))

print("The length of the word is :",len(max(sen,key=len)))

