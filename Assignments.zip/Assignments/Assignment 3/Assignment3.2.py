a= input("Write something :")
b=input("Enter the word you want to search:")
print(a.count(b))