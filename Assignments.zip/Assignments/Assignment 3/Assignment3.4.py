inn = input("Please enter something : ")
l=len(inn)
print(l)
for x in range (0,l):
    print(inn,end='')