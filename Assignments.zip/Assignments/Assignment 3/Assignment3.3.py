i = input("Please enter something : ")
if (i[0:len(i)] == i[::-1]):
    print("It's a Pallindrom")
else:
    print("It's not a pallindrom")
