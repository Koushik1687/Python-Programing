j = input("Please enter a string :").split()

h = ""

for x in j:
    h += x[0]
print(h)