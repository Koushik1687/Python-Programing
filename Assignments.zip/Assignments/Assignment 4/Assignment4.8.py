lt = []
for i in range(1,21):
    lt.append(i)
    if i%4==0:
        print(i)
