f = open("D:\\Coding\\Python\\Python-Programing\\Assignments\\Assignment 7\\Assignment7.5.txt","r")
print(f.read())
f.close()