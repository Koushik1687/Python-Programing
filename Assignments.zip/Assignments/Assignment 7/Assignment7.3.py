lt =  [3,4,5,6]
k =lt.pop(0)
lt.append(k)
print(lt)
