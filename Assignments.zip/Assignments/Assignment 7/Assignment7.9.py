with open("D:\\Coding\\Python\\Python-Programing\\Assignments\\Assignment 7\\Assignment7.9.txt", "r") as file:  
    for line in file:  
        print(line.strip())
        
