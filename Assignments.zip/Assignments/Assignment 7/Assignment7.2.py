lt = []
for i in range(1,21):
    if i % 4==0:
        lt.append(i)
print(lt)